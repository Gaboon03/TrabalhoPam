
import UserMenu from '@/components/UserMenu';
import axios from 'axios';
import React from 'react';
import { Button, Image, ScrollView, Text, View } from 'react-native';


interface Alunos {
  createdAt: string
  name: string
  id: string
  avatar: string
}


export default function HomeScreen() {
const [Users, setUsers] = React.useState<Alunos[]>([])

const GetUsers = async () =>{
  const { data } = await axios.get("https://6859b0a69f6ef9611153f0be.mockapi.io/:endpoint")
  setUsers(data)
  console.log(data)
}

const ListUsers = () =>{
   return Users.map(User => {
    return(
      <UserMenu>
        <Image source={{ uri: User.avatar }} style={{ width: 100, height: 100, borderRadius: 10, marginBottom: 10,}} />
        <Text>ID: {User.id}</Text>
        <Text style={{marginBottom: 10}}>Nome: {User.name}</Text>
        <Button 
          title='Ver Mais'
        />
      </UserMenu>
      
    )
   })
}

React.useEffect(() => {
   GetUsers()
}, [])

  return (
   <ScrollView style={{backgroundColor: 'black'}}>
   <View style={{flexDirection: 'row', flexWrap: 'wrap', justifyContent:'space-around', padding:10}}>
      {ListUsers()}
   </View>
   </ScrollView>
  );
}
